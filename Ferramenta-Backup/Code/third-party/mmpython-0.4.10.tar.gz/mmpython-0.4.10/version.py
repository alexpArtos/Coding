# the intention of this file is to make it possible to check
# for the program using this lib if it's an up-to-date version

# "offical" version of mmpython
VERSION = '0.4.10'

# latest major change (date as integer)
CHANGED = 20060926

